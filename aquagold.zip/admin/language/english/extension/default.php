<?php
$_['lang_openbay_new']              = 'Create new listing';
$_['lang_openbay_edit']             = 'View / Edit listing';
$_['lang_openbay_fix']              = 'Fix errors';
$_['lang_openbay_processing']       = 'Processing';

$_['lang_amazonus_saved']           = 'Saved (not uploaded)';
$_['lang_amazon_saved']             = 'Saved (not uploaded)';

$_['lang_markets']                  = 'Markets';
$_['lang_bulk_btn']                 = 'eBay bulk upload';
$_['lang_bulk_amazon_btn']          = 'Amazon EU bulk upload';

$_['lang_marketplace']              = 'Marketplace';
$_['lang_status']                   = 'Status';
$_['lang_option']                   = 'Option';
?>