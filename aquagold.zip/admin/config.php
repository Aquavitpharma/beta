<?php
// HTTP
define('HTTP_SERVER', 'http://aquagoldfinetouch.com/admin/');
define('HTTP_CATALOG', 'http://aquagoldfinetouch.com/');

// HTTPS
define('HTTPS_SERVER', 'http://aquagoldfinetouch.com/admin/');
define('HTTPS_CATALOG', 'http://aquagoldfinetouch.com/');

// DIR
define('DIR_APPLICATION', '/home/content/51/8609451/html/aquagold/admin/');
define('DIR_SYSTEM', '/home/content/51/8609451/html/aquagold/system/');
define('DIR_DATABASE', '/home/content/51/8609451/html/aquagold/system/database/');
define('DIR_LANGUAGE', '/home/content/51/8609451/html/aquagold/admin/language/');
define('DIR_TEMPLATE', '/home/content/51/8609451/html/aquagold/admin/view/template/');
define('DIR_CONFIG', '/home/content/51/8609451/html/aquagold/system/config/');
define('DIR_IMAGE', '/home/content/51/8609451/html/aquagold/image/');
define('DIR_CACHE', '/home/content/51/8609451/html/aquagold/system/cache/');
define('DIR_DOWNLOAD', '/home/content/51/8609451/html/aquagold/download/');
define('DIR_LOGS', '/home/content/51/8609451/html/aquagold/system/logs/');
define('DIR_CATALOG', '/home/content/51/8609451/html/aquagold/catalog/');

// DB
define('DB_DRIVER', 'mysql');
define('DB_HOSTNAME', '68.178.216.52');
define('DB_USERNAME', 'aquagold');
define('DB_PASSWORD', 'Aquagold2014!');
define('DB_DATABASE', 'aquagold');
define('DB_PREFIX', 'oc_');
?>